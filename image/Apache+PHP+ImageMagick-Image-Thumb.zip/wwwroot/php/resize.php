<?php
if( isset($_GET['file']) ) {
    $path = trim($_GET['file']);//��ͼ·��
	preg_match('/(?P<imgFolder>.+\/)(?P<imgName>\w+\.(jpg|jpeg|png))!(?P<w>(-|(\d+)))x(?P<h>(-|(\d+)))/',$path,$match);
	$imgFolder = 'D:/software/wwwroot/Mobile/';
	$path = $imgFolder . $path;
	$imgFolder = $imgFolder . $match['imgFolder'];
	$imgName = $match['imgName'];
	$w = $match['w'];
	$h = $match['h'];
    $srcPath = $imgFolder . $match['imgName'];

    if( is_file( $srcPath ) ) {
        $ext = strtolower( strrchr( $imgName , '.' ) );
        if( $ext == '.jpg' || $ext == '.jpeg') {
            header ( 'content-type:image/jpg' );
        } elseif( $ext == '.png' ) {
            header ( 'content-type:image/png' );
        } else {
            header('HTTP/1.1 404 Not Found');
        }
        $w = preg_match('/^\d+$/i', $w) ? intval($w) : 0;
		$h = preg_match('/^\d+$/i', $h) ? intval($h) : 0;
        if (file_exists($path) == false){
			$image = new Imagick($srcPath);
			$real_w = $image->getImageWidth();
            $real_h = $image->getImageHeight();

			if(($real_w > $w && $w > 0) || ($real_h > $h && $h > 0)){
			    $w_ = ($real_w * $h * 1.0) / ($real_h * 1.0);
				$h_ = ($real_h * $w * 1.0) / ($real_w * 1.0);
				if($w == 0){
					$w = $w_;
					$h_ = ($real_h * $w * 1.0) / ($real_w * 1.0);
				}
				if($h == 0){
					$h = $h_;
					$w_ = ($real_w * $h * 1.0) / ($real_h * 1.0);
				}
				if($w_ < $w){
					$w = $w_;
				}
				else{
				    $h = $h_;
				}
			}
			else{
				$w = $real_w;
				$h = $real_h;
			}
			$image->setImageCompression(Imagick::COMPRESSION_JPEG);
			$image->setImageCompressionQuality(75);
			$image->stripImage();
			$image->setImageFormat('JPEG');
			$image->thumbnailImage($w, $h);
			$image->writeImages($path, true);
		}
        echo file_get_contents($path);
        exit;
    }
}
header('HTTP/1.1 404 Not Found');